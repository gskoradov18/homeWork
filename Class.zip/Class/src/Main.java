public class Main {
    public static void main(String[] args) {
       Dog d=new Dog("Ivan");
       d.setName("Tanka");
       d.bark();
    }
}