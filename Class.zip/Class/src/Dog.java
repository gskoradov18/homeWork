public class Dog {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    //here comes class's body
private String name;

    public Dog()
    {
        this.name="";
    }

    public Dog(String name)
    {
        this.name=name;
    }


    public void bark(){
        System.out.printf("Dog %s said: Wow-wow!%n",name);
    }
}
